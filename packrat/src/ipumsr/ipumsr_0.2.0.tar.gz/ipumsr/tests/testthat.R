library(testthat)
library(ipumsr)

test_check("ipumsr")
