#' @importFrom magrittr "%>%"
#' @importFrom magrittr "%<>%"
#' @importFrom stats "dist"
#' @importFrom purrr map_df
#' @importFrom purrr map
#' @importFrom tibble tibble
#' @importFrom tibble as.tibble
#' @import dplyr
#' @import ggplot2
NULL
utils::globalVariables(c(".", "cn", "cor"))