library(testthat)
library(mapview)

test_check("mapview")
