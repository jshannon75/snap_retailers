library("testthat")

library("dbscan")
test_check("dbscan")
