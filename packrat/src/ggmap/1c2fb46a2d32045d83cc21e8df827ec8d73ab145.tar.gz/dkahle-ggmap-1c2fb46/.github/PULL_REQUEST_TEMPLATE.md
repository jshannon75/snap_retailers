## Before you open your PR

- [ ] Did you run R CMD CHECK?
- [ ] Did you run `roxygen2::roxygenise(".")`?

Thanks for contributing!

