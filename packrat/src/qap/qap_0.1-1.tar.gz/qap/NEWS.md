# qap 0.1-1 (2017-02-26)
  
* fixed reading optimal solution in read_qaplib.
* added test.
* native routines are now registered.

# qap 0.1-0 (2015-10-05)

* initial release.
