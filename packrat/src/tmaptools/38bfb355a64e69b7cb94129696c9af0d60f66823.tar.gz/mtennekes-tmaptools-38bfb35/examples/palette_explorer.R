\dontrun{
if (require(shiny) && require(shinyjs)) {
    palette_explorer()
}
}
