### Methods for accessing loglik value maximum likelihood estimates

logLik.summary.maxLik <- function( object, ...)
    object$loglik

logLik.maxLik <- function( object, ...)
    object$maximum
