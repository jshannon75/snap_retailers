intervals
=========
[![Build Status](https://travis-ci.org/edzer/intervals.png?branch=master)](https://travis-ci.org/edzer/intervals)

R package intervals
