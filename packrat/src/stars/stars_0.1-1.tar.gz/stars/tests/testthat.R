## load dependencies
library(testthat)

## test package
test_check("stars")
